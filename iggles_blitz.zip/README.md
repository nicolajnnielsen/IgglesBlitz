# IgglesBlitz WordPress Theme

A WordPress Theme for the Philadelphia Eagles blog IgglesBlitz

## TODO
- Fix id and element of header widgets
- focus state on various buttons
- 

### Recommended WordPress Settings
- show at most 9 posts

* A custom header implementation in `inc/custom-header.php` just add the code snippet found in the comments of `inc/custom-header.php` to your `header.php` template.
* Custom template tags in `inc/template-tags.php` that keep your templates clean and neat and prevent code duplication.
* Licensed under GPLv2 or later. :) Use it to make something cool.
